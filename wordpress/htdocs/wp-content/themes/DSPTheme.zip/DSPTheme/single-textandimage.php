<?php
 /* Template Name: TextAndImage Template */
?>


