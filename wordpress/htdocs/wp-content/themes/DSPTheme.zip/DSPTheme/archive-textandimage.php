<?php
 /* Template Name: TextAndImage Archive Template */
?>


