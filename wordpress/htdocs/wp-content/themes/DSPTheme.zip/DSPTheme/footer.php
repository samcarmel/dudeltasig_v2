    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="list-inline">
                        <li>
                            <a href="#about">About</a>
                        </li>
                        <li>
                            <a href="#recruitment">Recruitment</a>
                        </li>
                        <li>
                            <a href="#brothers">Brothers</a>
                        </li>
                        <li>
                            <a href="#donate">Donate</a>
                        </li>
                    </ul>
                    <p class="copyright text-muted small">Copyright &copy; Delta Sigma Phi Drexel University 2016. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </footer>

</body>

</html>